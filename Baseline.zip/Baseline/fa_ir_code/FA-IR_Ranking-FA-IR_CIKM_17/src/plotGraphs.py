from readWriteRankings.readAndWriteRankings import loadPickleFromDisk

data = loadPickleFromDisk("../results/rankingDumps/Compas/Gender/CompasGenderColorblindRanking.pickle")
print(data)
