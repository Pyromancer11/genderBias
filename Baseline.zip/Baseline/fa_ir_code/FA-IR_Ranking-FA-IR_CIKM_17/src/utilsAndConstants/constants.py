'''
Created on Mar 29, 2017

contains global constants for ranking creation and evaluation

@author: meike.zehlike
'''

ESSENTIALLY_ZERO = 0.000000000001
ESSENTIALLY_ONE = 0.999999999999
