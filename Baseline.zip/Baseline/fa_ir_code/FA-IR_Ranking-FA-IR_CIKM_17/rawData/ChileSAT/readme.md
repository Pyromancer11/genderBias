# Stats:                                                                                        
  P077
* Admission Year    Total       /   Male    Female    /  Chilean     Foreigner  /   Region  /   Private Paid    Subsidized private  Municipal   No data
                                                                                                            1       2               3           0




    2004            159250
